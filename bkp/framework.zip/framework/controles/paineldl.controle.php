<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 28/05/2014 10:11:39
 */

namespace Controle;

class PainelDL extends PrincipalSistema{
    public function __construct(){
        parent::__construct('painel-dl');
    } // Fim do método mágico de construção da classe
    
    public function __destruct(){
        parent::__destruct();
    } // Fim do método mágico de __destruicao
    
    public function _home(){
        # Preparar a visão
        $this->_escolhertpl('home', array());
        $this->obj_v->_titulo(\DL3::$ap_nome);
        
        $mod_cs = new \Modelo\ContatoSite();
        
        # Incluir parâmetros
        $this->obj_v->_incluirparams('relatorio-contatos', $mod_cs->_rel_contar_por_assuntos());
    } // Fim do método _home
    
    /**
     * Obter informações do Google Analytics
     */
    public function _ganalytics($dt_inicio, $dt_fim, $dimensao = 'day', $metricas = array('visits')){
        # Conectar ao Google Analytics
        $obj_ga = new \gapi(\DL3::$ga_usuario, \DL3::$ga_senha);
        
        # Retornar as informações
        $obj_ga->requestReportData(
            \DL3::$ga_perfil_id, $dimensao, $metricas, null, null,
            \Funcoes::_formatardatahora($dt_inicio, 'Y-m-d'), \Funcoes::_formatardatahora($dt_fim, 'Y-m-d')
        );
        
        # Visitas
        $infos = array();
                
        foreach( $obj_ga->getResults() as $info ):
            $infos[] = array('dimensao' => (string)$info, 'visitas' => $info->getVisits());
        endforeach;
        
        echo json_encode($infos);
    } // Fim do método _ganalytics
} // Fim do controle PainelDL
