
<footer class="dl">
    <?= \DL3::$ap_nome; ?> &COPY; <?= date('Y'); ?>
</footer>
