<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Traditional Chinese Version
* @author liqwei <liqwei@liqwei.com>
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP é¯èª¤ï¼ç»éå¤±æã';
$PHPMAILER_LANG['connect_host'] = 'SMTP é¯èª¤ï¼ç¡æ³é£æ¥å° SMTP ä¸»æ©ã';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP é¯èª¤ï¼æ¸æä¸è¢«æ¥åã';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = 'æªç¥ç·¨ç¢¼: ';
$PHPMAILER_LANG['file_access'] = 'ç¡æ³è¨ªåæä»¶ï¼';
$PHPMAILER_LANG['file_open'] = 'æä»¶é¯èª¤ï¼ç¡æ³æéæä»¶ï¼';
$PHPMAILER_LANG['from_failed'] = 'ç¼éå°åé¯èª¤ï¼';
$PHPMAILER_LANG['execute'] = 'ç¡æ³å·è¡ï¼';
$PHPMAILER_LANG['instantiate'] = 'æªç¥å½æ¸èª¿ç¨ã';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['provide_address'] = 'å¿é æä¾è³å°ä¸åæ¶ä»¶äººå°åã';
$PHPMAILER_LANG['mailer_not_supported'] = 'ç¼ä¿¡å®¢æ¶ç«¯ä¸è¢«æ¯æã';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP é¯èª¤ï¼æ¶ä»¶äººå°åé¯èª¤ï¼';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
