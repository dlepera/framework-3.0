<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Polish Version
*/

$PHPMAILER_LANG['authenticate'] = 'BÅÄd SMTP: Nie moÅ¼na przeprowadziÄ autentykacji.';
$PHPMAILER_LANG['connect_host'] = 'BÅÄd SMTP: Nie moÅ¼na poÅÄczyÄ siÄ z wybranym hostem.';
$PHPMAILER_LANG['data_not_accepted'] = 'BÅÄd SMTP: Dane nie zostaÅy przyjÄte.';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = 'Nieznany sposób kodowania znaków: ';
$PHPMAILER_LANG['execute'] = 'Nie moÅ¼na uruchomiÄ: ';
$PHPMAILER_LANG['file_access'] = 'Brak dostÄpu do pliku: ';
$PHPMAILER_LANG['file_open'] = 'Nie moÅ¼na otworzyÄ pliku: ';
$PHPMAILER_LANG['from_failed'] = 'NastÄpujÄcy adres Nadawcy jest jest nieprawidÅowy: ';
$PHPMAILER_LANG['instantiate'] = 'Nie moÅ¼na wywoÅaÄ funkcji mail(). SprawdÅº konfiguracjÄ serwera.';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['provide_address'] = 'NaleÅ¼y podaÄ prawidÅowy adres email Odbiorcy.';
$PHPMAILER_LANG['mailer_not_supported'] = 'Wybrana metoda wysyÅki wiadomoÅci nie jest obsÅugiwana.';
$PHPMAILER_LANG['recipients_failed'] = 'BÅÄd SMTP: NastÄpujÄcy odbiorcy sÄ nieprawidÅowi: ';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
