<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Faroese Version [language of the Faroe Islands, a Danish dominion]
* This file created: 11-06-2004
* Supplied by Dávur SÃ¸rensen [www.profo-webdesign.dk]
*/

$PHPMAILER_LANG['authenticate']         = 'SMTP feilur: Kundi ikki góÃ°kenna.';
$PHPMAILER_LANG['connect_host']         = 'SMTP feilur: Kundi ikki knÃ½ta samband viÃ° SMTP vert.';
$PHPMAILER_LANG['data_not_accepted']    = 'SMTP feilur: Data ikki góÃ°kent.';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding']             = 'Ãkend encoding: ';
$PHPMAILER_LANG['execute']              = 'Kundi ikki útfÃ¸ra: ';
$PHPMAILER_LANG['file_access']          = 'Kundi ikki tilganga fílu: ';
$PHPMAILER_LANG['file_open']            = 'Fílu feilur: Kundi ikki opna fílu: ';
$PHPMAILER_LANG['from_failed']          = 'fylgjandi Frá/From adressa miseydnaÃ°ist: ';
$PHPMAILER_LANG['instantiate']          = 'Kuni ikki instantiera mail funktión.';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' er ikki supporteraÃ°.';
$PHPMAILER_LANG['provide_address']      = 'Tú skal uppgeva minst móttakara-emailadressu(r).';
$PHPMAILER_LANG['recipients_failed']    = 'SMTP Feilur: Fylgjandi móttakarar miseydnaÃ°ust: ';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
