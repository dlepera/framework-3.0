<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Japanese Version
* By Mitsuhiro Yoshida - http://mitstek.com/
*/

$PHPMAILER_LANG['authenticate'] = 'SMTPã¨ã©ã¼: èªè¨¼ã§ãã¾ããã§ããã';
$PHPMAILER_LANG['connect_host'] = 'SMTPã¨ã©ã¼: SMTPãã¹ãã«æ¥ç¶ã§ãã¾ããã§ããã';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTPã¨ã©ã¼: ãã¼ã¿ãåãä»ãããã¾ããã§ããã';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = 'ä¸æãªã¨ã³ã³ã¼ãã£ã³ã°: ';
$PHPMAILER_LANG['execute'] = 'å®è¡ã§ãã¾ããã§ãã: ';
$PHPMAILER_LANG['file_access'] = 'ãã¡ã¤ã«ã«ã¢ã¯ã»ã¹ã§ãã¾ãã: ';
$PHPMAILER_LANG['file_open'] = 'ãã¡ã¤ã«ã¨ã©ã¼: ãã¡ã¤ã«ãéãã¾ãã: ';
$PHPMAILER_LANG['from_failed'] = 'æ¬¡ã®Fromã¢ãã¬ã¹ã«ééããããã¾ã: ';
$PHPMAILER_LANG['instantiate'] = 'ã¡ã¼ã«é¢æ°ãæ­£å¸¸ã«åä½ãã¾ããã§ããã';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['provide_address'] = 'å°ãªãã¨ã1ã¤ã¡ã¼ã«ã¢ãã¬ã¹ã æå®ããå¿è¦ãããã¾ãã';
$PHPMAILER_LANG['mailer_not_supported'] = ' ã¡ã¼ã©ã¼ããµãã¼ãããã¦ãã¾ããã';
$PHPMAILER_LANG['recipients_failed'] = 'SMTPã¨ã©ã¼: æ¬¡ã®åä¿¡èã¢ãã¬ã¹ã« ééããããã¾ã: ';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
