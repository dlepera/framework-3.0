<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Simplified Chinese Version
* @author liqwei <liqwei@liqwei.com>
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP éè¯¯ï¼ç»å½å¤±è´¥ã';
$PHPMAILER_LANG['connect_host'] = 'SMTP éè¯¯ï¼æ æ³è¿æ¥å° SMTP ä¸»æºã';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP éè¯¯ï¼æ°æ®ä¸è¢«æ¥åã';
//$P$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = 'æªç¥ç¼ç : ';
$PHPMAILER_LANG['execute'] = 'æ æ³æ§è¡ï¼';
$PHPMAILER_LANG['file_access'] = 'æ æ³è®¿é®æä»¶ï¼';
$PHPMAILER_LANG['file_open'] = 'æä»¶éè¯¯ï¼æ æ³æå¼æä»¶ï¼';
$PHPMAILER_LANG['from_failed'] = 'åéå°åéè¯¯ï¼';
$PHPMAILER_LANG['instantiate'] = 'æªç¥å½æ°è°ç¨ã';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = 'åä¿¡å®¢æ·ç«¯ä¸è¢«æ¯æã';
$PHPMAILER_LANG['provide_address'] = 'å¿é¡»æä¾è³å°ä¸ä¸ªæ¶ä»¶äººå°åã';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP éè¯¯ï¼æ¶ä»¶äººå°åéè¯¯ï¼';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
