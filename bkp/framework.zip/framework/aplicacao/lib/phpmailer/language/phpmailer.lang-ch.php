<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Chinese Version
* By LiuXin: www.80x86.cn/blog/
*/

$PHPMAILER_LANG['authenticate'] = 'SMTP éè¯¯ï¼èº«ä»½éªè¯å¤±è´¥ã';
$PHPMAILER_LANG['connect_host'] = 'SMTP éè¯¯: ä¸è½è¿æ¥SMTPä¸»æºã';
$PHPMAILER_LANG['data_not_accepted'] = 'SMTP éè¯¯: æ°æ®ä¸å¯æ¥åã';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding'] = 'æªç¥ç¼ç ï¼';
$PHPMAILER_LANG['execute'] = 'ä¸è½æ§è¡: ';
$PHPMAILER_LANG['file_access'] = 'ä¸è½è®¿é®æä»¶ï¼';
$PHPMAILER_LANG['file_open'] = 'æä»¶éè¯¯ï¼ä¸è½æå¼æä»¶ï¼';
$PHPMAILER_LANG['from_failed'] = 'ä¸é¢çåéå°åé®ä»¶åéå¤±è´¥äºï¼ ';
$PHPMAILER_LANG['instantiate'] = 'ä¸è½å®ç°mailæ¹æ³ã';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' æ¨æéæ©çåéé®ä»¶çæ¹æ³å¹¶ä¸æ¯æã';
$PHPMAILER_LANG['provide_address'] = 'æ¨å¿é¡»æä¾è³å°ä¸ä¸ª æ¶ä¿¡äººçemailå°åã';
$PHPMAILER_LANG['recipients_failed'] = 'SMTP éè¯¯ï¼ ä¸é¢ç æ¶ä»¶äººå¤±è´¥äºï¼ ';
//$PHPMAILER_LANG['signing']              = 'Signing Error: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
