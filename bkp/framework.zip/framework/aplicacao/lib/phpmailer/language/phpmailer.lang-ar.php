<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Arabic Version, UTF-8
* by : bahjat al mostafa <bahjat983@hotmail.com>
*/

$PHPMAILER_LANG['authenticate']         = 'SMTP Error: ÙÙ ÙØ³ØªØ·Ø¹ ØªØ£ÙÙØ¯ Ø§ÙÙÙÙØ©.';
$PHPMAILER_LANG['connect_host']         = 'SMTP Error: ÙÙ ÙØ³ØªØ·Ø¹ Ø§ÙØ§ØªØµØ§Ù Ø¨ÙØ®Ø¯Ù SMTP.';
$PHPMAILER_LANG['data_not_accepted']    = 'SMTP Error: ÙÙ ÙØªÙ ÙØ¨ÙÙ Ø§ÙÙØ¹ÙÙÙØ§Øª .';
//$PHPMAILER_LANG['empty_message']        = 'Message body empty';
$PHPMAILER_LANG['encoding']             = 'ØªØ±ÙÙØ² ØºÙØ± ÙØ¹Ø±ÙÙ: ';
$PHPMAILER_LANG['execute']              = 'ÙÙ Ø£Ø³ØªØ·Ø¹ ØªÙÙÙØ° : ';
$PHPMAILER_LANG['file_access']          = 'ÙÙ ÙØ³ØªØ·Ø¹ Ø§ÙÙØµÙÙ ÙÙÙÙÙ: ';
$PHPMAILER_LANG['file_open']            = 'File Error: ÙÙ ÙØ³ØªØ·Ø¹ ÙØªØ­ Ø§ÙÙÙÙ: ';
$PHPMAILER_LANG['from_failed']          = 'Ø§ÙØ¨Ø±ÙØ¯ Ø§ÙØªØ§ÙÙ ÙÙ ÙØ³ØªØ·Ø¹ Ø§Ø±Ø³Ø§Ù Ø§ÙØ¨Ø±ÙØ¯ ÙÙ : ';
$PHPMAILER_LANG['instantiate']          = 'ÙÙ ÙØ³ØªØ·Ø¹ ØªÙÙÙØ± Ø®Ø¯ÙØ© Ø§ÙØ¨Ø±ÙØ¯.';
//$PHPMAILER_LANG['invalid_address']        = 'Not sending, email address is invalid: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' mailer ØºÙØ± ÙØ¯Ø¹ÙÙ.';
//$PHPMAILER_LANG['provide_address']      = 'You must provide at least one recipient email address.';
$PHPMAILER_LANG['recipients_failed']    = 'SMTP Error: Ø§ÙØ£Ø®Ø·Ø§Ø¡ Ø§ÙØªØ§ÙÙØ© ' .
                                          'ÙØ´Ù ÙÙ Ø§ÙØ§Ø±Ø³Ø§Ù ÙÙÙ ÙÙ : ';
$PHPMAILER_LANG['signing']              = 'Ø®Ø·Ø£ ÙÙ Ø§ÙØªÙÙÙØ¹: ';
//$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP Connect() failed.';
//$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
//$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';
?>
