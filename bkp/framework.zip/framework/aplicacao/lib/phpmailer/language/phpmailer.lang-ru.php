<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Russian Version by Alexey Chumakov <alex@chumakov.ru>
*/

$PHPMAILER_LANG['authenticate']         = 'ÐÑÐ¸Ð±ÐºÐ° SMTP: Ð¾ÑÐ¸Ð±ÐºÐ° Ð°Ð²ÑÐ¾ÑÐ¸Ð·Ð°ÑÐ¸Ð¸.';
$PHPMAILER_LANG['connect_host']         = 'ÐÑÐ¸Ð±ÐºÐ° SMTP: Ð½Ðµ ÑÐ´Ð°ÐµÑÑÑ Ð¿Ð¾Ð´ÐºÐ»ÑÑÐ¸ÑÑÑÑ Ðº ÑÐµÑÐ²ÐµÑÑ SMTP.';
$PHPMAILER_LANG['data_not_accepted']    = 'ÐÑÐ¸Ð±ÐºÐ° SMTP: Ð´Ð°Ð½Ð½ÑÐµ Ð½Ðµ Ð¿ÑÐ¸Ð½ÑÑÑ.';
$PHPMAILER_LANG['encoding']             = 'ÐÐµÐ¸Ð·Ð²ÐµÑÑÐ½ÑÐ¹ Ð²Ð¸Ð´ ÐºÐ¾Ð´Ð¸ÑÐ¾Ð²ÐºÐ¸: ';
$PHPMAILER_LANG['execute']              = 'ÐÐµÐ²Ð¾Ð·Ð¼Ð¾Ð¶Ð½Ð¾ Ð²ÑÐ¿Ð¾Ð»Ð½Ð¸ÑÑ ÐºÐ¾Ð¼Ð°Ð½Ð´Ñ: ';
$PHPMAILER_LANG['file_access']          = 'ÐÐµÑ Ð´Ð¾ÑÑÑÐ¿Ð° Ðº ÑÐ°Ð¹Ð»Ñ: ';
$PHPMAILER_LANG['file_open']            = 'Ð¤Ð°Ð¹Ð»Ð¾Ð²Ð°Ñ Ð¾ÑÐ¸Ð±ÐºÐ°: Ð½Ðµ ÑÐ´Ð°ÐµÑÑÑ Ð¾ÑÐºÑÑÑÑ ÑÐ°Ð¹Ð»: ';
$PHPMAILER_LANG['from_failed']          = 'ÐÐµÐ²ÐµÑÐ½ÑÐ¹ Ð°Ð´ÑÐµÑ Ð¾ÑÐ¿ÑÐ°Ð²Ð¸ÑÐµÐ»Ñ: ';
$PHPMAILER_LANG['instantiate']          = 'ÐÐµÐ²Ð¾Ð·Ð¼Ð¾Ð¶Ð½Ð¾ Ð·Ð°Ð¿ÑÑÑÐ¸ÑÑ ÑÑÐ½ÐºÑÐ¸Ñ mail.';
$PHPMAILER_LANG['provide_address']      = 'ÐÐ¾Ð¶Ð°Ð»ÑÐ¹ÑÑÐ°, Ð²Ð²ÐµÐ´Ð¸ÑÐµ ÑÐ¾ÑÑ Ð±Ñ Ð¾Ð´Ð¸Ð½ Ð°Ð´ÑÐµÑ e-mail Ð¿Ð¾Ð»ÑÑÐ°ÑÐµÐ»Ñ.';
$PHPMAILER_LANG['mailer_not_supported'] = ' - Ð¿Ð¾ÑÑÐ¾Ð²ÑÐ¹ ÑÐµÑÐ²ÐµÑ Ð½Ðµ Ð¿Ð¾Ð´Ð´ÐµÑÐ¶Ð¸Ð²Ð°ÐµÑÑÑ.';
$PHPMAILER_LANG['recipients_failed']    = 'ÐÑÐ¸Ð±ÐºÐ° SMTP: Ð¾ÑÐ¿ÑÐ°Ð²ÐºÐ° Ð¿Ð¾ ÑÐ»ÐµÐ´ÑÑÑÐ¸Ð¼ Ð°Ð´ÑÐµÑÐ°Ð¼ Ð¿Ð¾Ð»ÑÑÐ°ÑÐµÐ»ÐµÐ¹ Ð½Ðµ ÑÐ´Ð°Ð»Ð°ÑÑ: ';
$PHPMAILER_LANG['empty_message']        = 'ÐÑÑÑÐ¾Ðµ ÑÐµÐ»Ð¾ ÑÐ¾Ð¾Ð±ÑÐµÐ½Ð¸Ñ';
$PHPMAILER_LANG['invalid_address']        = 'ÐÐµ Ð¾ÑÐ¾ÑÐ»Ð°Ð½Ð¾, Ð½ÐµÐ¿ÑÐ°Ð²Ð¸Ð»ÑÐ½ÑÐ¹ ÑÐ¾ÑÐ¼Ð°Ñ email Ð°Ð´ÑÐµÑÐ°: ';
$PHPMAILER_LANG['signing']              = 'ÐÑÐ¸Ð±ÐºÐ° Ð¿Ð¾Ð´Ð¿Ð¸ÑÑÐ²Ð°Ð½Ð¸Ñ: ';
$PHPMAILER_LANG['smtp_connect_failed']  = 'ÐÑÐ¸Ð±ÐºÐ° ÑÐ¾ÐµÐ´Ð¸Ð½ÐµÐ½Ð¸Ñ Ñ SMTP-ÑÐµÑÐ²ÐµÑÐ¾Ð¼';
$PHPMAILER_LANG['smtp_error']           = 'ÐÑÐ¸Ð±ÐºÐ° SMTP-ÑÐµÑÐ²ÐµÑÐ°: ';
$PHPMAILER_LANG['variable_set']         = 'ÐÐµÐ²Ð¾Ð·Ð¼Ð¾Ð¶Ð½Ð¾ ÑÑÑÐ°Ð½Ð¾Ð²Ð¸ÑÑ Ð¸Ð»Ð¸ Ð¿ÐµÑÐµÑÑÑÐ°Ð½Ð¾Ð²Ð¸ÑÑ Ð¿ÐµÑÐµÐ¼ÐµÐ½Ð½ÑÑ: ';

?>
