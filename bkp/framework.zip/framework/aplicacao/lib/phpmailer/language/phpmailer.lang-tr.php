<?php
/**
* PHPMailer language file: refer to English translation for definitive list
* Turkish version
* TÃ¼rkçe Versiyonu
* ÃZYAZILIM - Elçin Ãzel - Can YÃ½lmaz - Mehmet BenlioÃ°lu
*/

$PHPMAILER_LANG['authenticate']         = 'SMTP HatasÄ±: DoÄrulanamÄ±yor.';
$PHPMAILER_LANG['connect_host']         = 'SMTP HatasÄ±: SMTP hosta baÄlanÄ±lamÄ±yor.';
$PHPMAILER_LANG['data_not_accepted']    = 'SMTP HatasÄ±: Veri kabul edilmedi.';
$PHPMAILER_LANG['empty_message']        = 'Mesaj içeriÄi boÅ';
$PHPMAILER_LANG['encoding']             = 'Bilinmeyen Åifreleme: ';
$PHPMAILER_LANG['execute']              = 'ÃalÄ±tÄ±rÄ±lamÄ±yor: ';
$PHPMAILER_LANG['file_access']          = 'Dosyaya eriÅilemiyor: ';
$PHPMAILER_LANG['file_open']            = 'Dosya HatasÄ±: Dosya açÄ±lamÄ±yor: ';
$PHPMAILER_LANG['from_failed']          = 'BaÅarÄ±sÄ±z olan gÃ¶nderici adresi: ';
$PHPMAILER_LANG['instantiate']          = 'Ãrnek mail fonksiyonu oluÅturulamadÄ±.';
$PHPMAILER_LANG['invalid_address']        = 'GÃ¶nderilmedi, email adresi geçersiz: ';
$PHPMAILER_LANG['provide_address']      = 'En az bir tane mail adresi belirtmek zorundasÄ±nÄ±z alÄ±cÄ±nÄ±n email adresi.';
$PHPMAILER_LANG['mailer_not_supported'] = ' mailler desteklenmemektedir.';
$PHPMAILER_LANG['recipients_failed']    = 'SMTP HatasÄ±: alÄ±cÄ±lara ulaÄ±madÄ±: ';
$PHPMAILER_LANG['signing']              = 'Ä°mzalama hatasÄ±: ';
$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP baÄlantÄ±() baÅarÄ±sÄ±z.';
$PHPMAILER_LANG['smtp_error']           = 'SMTP sunucu hatasÄ±: ';
$PHPMAILER_LANG['variable_set']         = 'AyarlanamÄ±yor yada sÄ±fÄ±rlanamÄ±yor: ';
?>
