<?php

/**
 * @Autor	: Diego Lepera
 * @Projeto	: FrameworkDL
 * @Data	: 15/05/2014 16:35:23
 */

# Diretórios
$this->_dir_raiz('/framework/');
self::$dir_css = '/aplicacao/temas/painel/';

# Configurção do sistema
$this->_carregaridioma('pt-BR');
self::$ap_nome      = 'Painel-DL';
self::$ap_slogan    = 'Gerenciador de conteúdo';
self::$ap_favicon   = 'favicon-painel.png';
self::$conf_versao  = '<span class="dl-versao">2.0 BETA</span>';

# Configuração do banco de dados
$this->bd_usuario   = 'root';
$this->bd_senha     = '$d5Ro0t';
$this->bd_base      = 'framework';

# Configurção dos plugins
self::$plugin_formulario_tema   = 'painel-dl';
self::$plugin_paginacao_tema    = 'painel-dl';

# Configurção do Google Analytics
self::$ga_perfil_id = 15189584;