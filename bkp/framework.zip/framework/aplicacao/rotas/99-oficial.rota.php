<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 16/05/2014 14:25:10
 */

$rotas['^(.*)/(.*)$'] = '/:controle/:acao';
