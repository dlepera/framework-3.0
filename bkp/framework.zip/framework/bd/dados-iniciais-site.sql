-- Inserir tipos de contato iniciais
INSERT INTO dl_site_dados_contato_tipos (tipo_dado_descr, tipo_dado_rede_social, tipo_dado_icone) VALUES
('Fone fixo', 0, null), ('Fone celular', 0, null), ('Fone comercial', 0, null), ('E-mail', 0, null),
('Facebook', 1, './aplicacao/uploads/contatos/facebook.png'), ('Google +', 1, './aplicacao/uploads/contatos/google+.png'),
('Instagram', 1, './aplicacao/uploads/contatos/instagram.png'), ('Twitter', 1, './aplicacao/uploads/contatos/twitter.png'),
('Youtube', 1, './aplicacao/uploads/contatos/youtube.png');
