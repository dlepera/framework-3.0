<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 20/05/2014 14:52:19
 */

namespace Modelo;

class LogEmail extends Principal{
    # Propriedades do modelo
    protected $id, $config, $ip, $classe, $tabela, $idreg, $mensagem, $status = 'S';
 
    public function __construct($tabela=null, $id=null){
        parent::__construct('dl_painel_email_logs', 'log_email_');
        
        $this->bd_select = "SELECT %s FROM %s";
        
        if( !is_null($tabela) && !is_null($id) )
            $this->_selecionarID((string)$tabela, (int)$id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $config
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $this->config
     * 
     * @return int - valor da propriedade $config
     */
    public function _config($valor=null){
        return is_null($valor) ? (int)$this->config
        : $this->config = (int)$valor;
    } // Fim do método _config
    
    /**
     * Obter ou editar o valor da propriedade $ip
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->ip
     * 
     * @return string - valor da propriedade $ip
     */
    public function _ip($valor=null){
        return is_null($valor) ? (string)$this->ip
        : $this->ip = (string)$valor;
    } // Fim do método _ip
    
    /**
     * Obter ou editar o valor da propriedade $classe
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->classe
     * 
     * @return string - valor da propriedade $classe
     */
    public function _classe($valor=null){
        return is_null($valor) ? (string)$this->classe
        : $this->classe = (string)$valor;
    } // Fim do método _classe
    
    /**
     * Obter ou editar o valor da propriedade $tabela
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->tabela
     * 
     * @return string - valor da propriedade $tabela
     */
    public function _tabela($valor=null){
        return is_null($valor) ? (string)$this->tabela
        : $this->tabela = (string)$valor;
    } // Fim do método _tabela
    
    /**
     * Obter ou editar o valor da propriedade $idreg
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->idreg
     * 
     * @return string - valor da propriedade $idreg
     */
    public function _idreg($valor=null){
        return is_null($valor) ? (string)$this->idreg
        : $this->idreg = (int)$valor;
    } // Fim do método _idreg
    
    /**
     * Obter ou editar o valor da propriedade $status
     * Os status aceitos são:
     * S: solicitado
     * E: enviado
     * F: falha
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->status
     * 
     * @return string - valor da propriedade $status
     */
    public function _status($valor=null){
        if( is_null($valor) )
            return $this->status;
        
        if( !in_array($valor, array('S', 'E', 'F')) )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);

        return $this->status = (string)$valor;
    } // Fim do método _status    
    
    /**
     * Obter ou editar o valor da propriedade $mensagem
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->mensagem
     * 
     * @return string - valor da propriedade $mensagem
     */
    public function _mensagem($valor=null){
        return is_null($valor) ? (string)$this->mensagem
        : $this->mensagem = (string)$valor;
    } // Fim do método _status
    
    /**
     * Selecionar um registro desse modelo pelo ID
     * 
     * @param int $id : ID do registro a ser selecionado
     * 
     * @return void
     */
    protected function _selecionarID($tabela, $idreg){
        if( !method_exists($this, '_listar') )
            throw new \Exception(printf(ERRO_PADRAO_METODO_NAO_EXISTE, '_listar'), 1500);
        
        $lis_m = end($this->_listar("{$this->bd_prefixo}tabela = '{$tabela}' AND {$this->bd_prefixo}idreg = {$idreg}"));
        
        # Carregar os dados obtidos do banco de dados
        # nas propriedades da classe
        foreach( $lis_m as $c => $m ):
            $p = preg_replace("~^{$this->bd_prefixo}~", '', $c);
            
            if( property_exists($this, $p) )
               $this->{$p} = $m;
        endforeach;
    } // Fim do método _selecionarID
} // Fim do modelo LogEmail
