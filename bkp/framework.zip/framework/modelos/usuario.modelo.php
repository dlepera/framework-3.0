<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 17:46:04
 */

namespace Modelo;

class Usuario extends Principal{
    protected $id, $info_grupo, $info_nome, $info_email, $info_telefone, $info_sexo, $info_login, $info_senha, $pref_idioma, $pref_tema,
            $pref_formato_data, $pref_num_registros = 20, $conf_bloq = 0, $conf_reset = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_painel_usuarios', 'usuario_');
        
        # Definir a query que fará a seleção dos resultados
        $this->bd_select = "SELECT"
            . " %s"
            . " FROM %s AS U"
            . " INNER JOIN dl_painel_grupos_usuarios AS G ON( G.grupo_usuario_id = U.{$this->bd_prefixo}info_grupo )"
            . " INNER JOIN dl_painel_idiomas AS I ON( I.idioma_id = U.{$this->bd_prefixo}pref_idioma )"
            . " INNER JOIN dl_painel_temas AS T ON( T.tema_id = U.{$this->bd_prefixo}pref_tema )"
            . " INNER JOIN dl_painel_formatos_data AS FD ON( FD.formato_data_id = U.{$this->bd_prefixo}pref_formato_data )"
            . " WHERE U.%sdelete = 0";
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
        
    /**
     * Obter ou editar o valor da propriedade $info_grupo
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $info_grupo
     * 
     * @return int - valor da propriedade $info_grupo
     */
    public function _info_grupo($valor=null){
        return is_null($valor) ? (int)$this->info_grupo
        : $this->info_grupo = (int)$valor;
    } // Fim do método _info_grupo
    
    /**
     * Obter ou editar o valor da propriedade $info_nome
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $info_nome
     * 
     * @return string: valor da propriedade $info_nome
     */
    public function _info_nome($valor=null){
        return is_null($valor) ? (string)$this->info_nome
        : $this->info_nome = (string)$valor;
    } // Fim do método _info_nome
    
    /**
     * Obter ou editar o valor da propriedade $info_email
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $info_email
     * 
     * @return string: valor da propriedade $info_nome
     */
    public function _info_email($valor=null){
        if( is_null($valor) )
            return $this->info_email;
        
        if( !empty($valor) && !$this->info_email = filter_var($valor, FILTER_VALIDATE_EMAIL, FILTER_NULL_ON_FAILURE) )
            throw new \Exception(sprintf(ERRO_PADRAO_FORMATO_NAO_CORRESPONDE, __METHOD__), 1500);
        
        return $this->info_email = (string)$valor;
    } // Fim do método _info_email
    
    /**
     * Obter ou editar o valor da propriedade $info_telefone
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $info_telefone
     * 
     * @return string: valor da propriedade $info_telefone
     */
    public function _info_telefone($valor=null){
        return is_null($valor) ? (string)$this->info_telefone
        : $this->info_telefone = (string)$valor;
    } // Fim do método _info_telefone
    
    /**
     * Obter ou editar o valor da propriedade $info_sexo
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $info_sexo
     * 
     * @return string: valor da propriedade $info_sexo
     */
    public function _info_sexo($valor=null){
        if( is_null($valor) )
            return $this->info_sexo;
        
        if( !empty($valor) && !in_array($valor, array('M', 'F')) )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->info_sexo = (string)$valor;
    } // Fim do método _info_sexo
    
    /**
     * Obter ou editar o valor da propriedade $info_login
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $info_login
     * 
     * @return string: valor da propriedade $info_login
     */
    public function _info_login($valor=null){
        return is_null($valor) ? (string)$this->info_login
        : $this->info_login = (string)$valor;
    } // Fim do método _info_login
    
    /**
     * Obter ou editar o valor da propriedade $info_senha
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $info_senha
     * 
     * @return string: valor da propriedade $info_senha
     */
    public function _info_senha($valor=null){
        return is_null($valor) ? (string)$this->info_senha
        : $this->info_senha = md5(md5((string)$valor));
    } // Fim do método _info_senha
    
    /**
     * Obter ou editar o valor da propriedade $pref_idioma
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $pref_idioma
     * 
     * @return int - valor da propriedade $pref_idioma
     */
    public function _pref_idioma($valor=null){
        return is_null($valor) ? (int)$this->pref_idioma
        : $this->pref_idioma = (int)$valor;
    } // Fim do método _pref_idioma
    
    /**
     * Obter ou editar o valor da propriedade $pref_tema
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $pref_tema
     * 
     * @return int - valor da propriedade $pref_tema
     */
    public function _pref_tema($valor=null){
        return is_null($valor) ? (int)$this->pref_tema
        : $this->pref_tema = (int)$valor;
    } // Fim do método _pref_tema
    
    /**
     * Obter ou editar o valor da propriedade $pref_formato_data
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $pref_formato_data
     * 
     * @return int - valor da propriedade $pref_formato_data
     */
    public function _pref_formato_data($valor=null){
        return is_null($valor) ? (int)$this->pref_formato_data
        : $this->pref_formato_data = (int)$valor;
    } // Fim do método _pref_formato_data
    
    /**
     * Obter ou editar o valor da propriedade $pref_num_registros
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $pref_num_registros
     * 
     * @return int - valor da propriedade $pref_num_registros
     */
    public function _pref_num_registros($valor=null){
        return is_null($valor) ? (int)$this->pref_num_registros
        : $this->pref_num_registros = (int)$valor;
    } // Fim do método _pref_idioma
    
    /**
     * Obter ou editar o valor da propriedade $conf_bloq
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $conf_bloq
     * 
     * @return string: valor da propriedade $conf_bloq
     */
    public function _conf_bloq($valor=null){
        if( is_null($valor) )
            return $this->conf_bloq;
        
        if( $valor < 0 || $valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->conf_bloq = (int)$valor;
    } // Fim do método _conf_bloq
    
    /**
     * Obter ou editar o valor da propriedade $conf_reset
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $conf_reset
     * 
     * @return string: valor da propriedade $conf_reset
     */
    public function _conf_reset($valor=null){
        if( is_null($valor) )
            return (int)$this->conf_reset;
        
        if( !empty($valor) && ($valor < 0 || $valor > 1) )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->conf_reset = (int)$valor;
    } // Fim do método _conf_reset
    
    /**
     * Alterar senha do usuário logado
     * 
     * @param string $senha_a - senha atual
     * @param string $senha_n - nova senha a ser utilizada
     * @param string $confirm - confirmação da senha digitada
     */
    public function _alterarsenha($senha_a, $senha_n, $confirm){
        if( $senha_a !== $this->info_senha )
            throw new \Exception(ERRO_USUARIO_ALTERARSENHA_ATUAL_NAO_CONFERE, 1500);
        
        if( $senha_n !== $confirm )
            throw new \Exception(ERRO_USUARIO_ALTERARSENHA_SENHAS_NAO_CONFEREM, 1500);
        
        $this->_info_senha($senha_n);
        
        $query = "UPDATE {$this->bd_tabela}"
                . " SET {$this->bd_prefixo}info_senha = '{$senha_n}',"
                . " {$this->bd_prefixo}conf_reset = 0"
                . " WHERE {$this->bd_prefixo}id = {$this->id}";
                
        if( \DL3::$bd_pdo->exec($query) !== false ):
            $_SESSION['usuario_conf_reset'] = 0;
            return true;
        else:
            return false;
        endif;
    } // Fim do método _alterarsenha
    
    /**
     * Resetar senha do usuário logado
     *
     * @param string $hash - Hash identificadora
     * @param string $senha_n - nova senha a ser utilizada
     * @param string $confirm - confirmação da senha digitada
     */
    public function _resetarsenha($hash, $senha_n, $confirm){
        if( $senha_n !== $confirm )
            throw new \Exception(ERRO_USUARIO_ALTERARSENHA_SENHAS_NAO_CONFEREM, 1500);
        
        $this->_info_senha($senha_n);
        
        $query = "UPDATE ". $this->_bd_tabela()
                . " SET {$this->bd_prefixo}info_senha = '{$senha_n}'"
                . " WHERE {$this->bd_prefixo}id = {$this->id}";
                
        if( \DL3::$bd_pdo->exec($query) ):
            $query = "UPDATE {$this->_bd_tabela}recuperacoes"
                . " SET recuperacao_status = 'R'"
                . " WHERE recuperacao_hash = '{$hash}' AND recuperacao_usuario = {$this->id}";
            return \DL3::$bd_pdo->exec($query);
        else:
            return false;
        endif;
    } // Fim do método _resetarsenha
    
    public function _salvar($salvar = true){
        $and_id = !$this->id ? '' : " AND {$this->bd_prefixo}id <> {$this->id}";
        
        # Verificar se o login já está cadastrado
        if( $this->_qtde_registros("{$this->bd_prefixo}info_login = '{$this->info_login}'{$and_id}") > 0 )
            throw new \Exception(ERRO_USUARIO_SALVAR_LOGIN_JA_CADASTRADO, 1500);
        
        # Verificar se o login já está cadastrado
        if( $this->_qtde_registros("{$this->bd_prefixo}info_email = '{$this->info_email}'{$and_id}") > 0 )
            throw new \Exception(ERRO_USUARIO_SALVAR_EMAIL_JA_CADASTRADO, 1500);
        
        $query = !$this->id ? $this->_criar_insert() : $this->_criar_update(null, array('usuario_info_senha', 'usuario_info_login'));
        
        if( !$salvar ) return $query;
        
        if( ($exec = \DL3::$bd_pdo->exec($query)) === false )
            throw new \Exception(
                    sprintf(ERRO_PADRAO_SALVAR_REGISTRO,
                        '<b>'. $this->bd_tabela .':</b><br><br>'. $query .'<br><br>'. \DL3::$bd_pdo->errorInfo()[2]
                    ),
                1500);
        
        # Se a ação executada foi um insert, carregar o ID gerado
        if( preg_match('~^(INSERT)~', $query) ):
            $this->id = \DL3::$bd_pdo->lastInsertID("{$this->bd_prefixo}id");
            return $this->id;
        else: 
            return $exec;
        endif;
    } // Fim do método 
} // Fim do modelo Usuario
