<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 20/05/2014 14:52:19
 */

namespace Modelo;

class ConfigEmail extends Principal{
    # Propriedades do modelo
    protected $id, $titulo, $host, $porta = 25, $autent, $cripto, $conta, $senha, $de_email, $de_nome, $responder_para, $html = 1, $principal = 1,
            $delete = 0;
 
    public function __construct($id=0){
        parent::__construct('dl_painel_email_config', 'config_email_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $titulo
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->titulo
     * 
     * @return string: valor da propriedade $titulo
     */
    public function _titulo($valor=null){
        return is_null($valor) ? (string)$this->titulo      
        : $this->titulo = (string)$valor;
    } // Fim do método _titulo
    
    /**
     * Obter ou editar o valor da propriedade $host
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->host
     * 
     * @return string - valor da propriedade $host
     */
    public function _host($valor=null){
        return is_null($valor) ? (string)$this->host
        : $this->host = (string)$valor;
    } // Fim do método _host
    
    /**
     * Obter ou editar o valor da propriedade $porta
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $this->porta
     * 
     * @return int: valor da propriedade $porta
     */
    public function _porta($valor=null){
        return is_null($valor) ? (int)$this->porta
        : $this->porta = (int)$valor;
    } // Fim do método _porta
    
    /**
     * Obter ou editar o valor da propriedade $autent
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $this->autent
     * 
     * @return int - valor da propriedade $autent
     */
    public function _autent($valor=null){
        if( is_null($valor) )
            return (int)$this->autent;
        
        if( (int)$valor < 0 || (int)$valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->autent = (int)$valor;
    } // Fim do método _autent
    
    /**
     * Obter ou editar o valor da propriedade $cripto
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->cripto
     * 
     * @return string: valor da propriedade $cripto
     */
    public function _cripto($valor=null){
        return is_null($valor) ? (string)$this->cripto
        : $this->cripto = (string)$valor;
    } // Fim do método _cripto
    
    /**
     * Obter ou editar o valor da propriedade $conta
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->conta
     * 
     * @return string: valor da propriedade $conta
     */
    public function _conta($valor=null){
        return is_null($valor) ? (string)$this->conta
        : $this->conta = (string)$valor;
    } // Fim do método _conta
    
    /**
     * Obter ou editar o valor da propriedade $senha
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->senha
     * 
     * @return string: valor da propriedade $senha
     */
    public function _senha($valor=null){
        return is_null($valor) ? (string)$this->senha
        : $this->senha = (string)$valor;
    } // Fim do método _senha
    
    /**
     * Obter ou editar o valor da propriedade $de_email
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->de_email
     * 
     * @return string: valor da propriedade $de_email
     */
    public function _de_email($valor=null){
        if( is_null($valor) )
            return $this->de_email;
        
        if( !$this->de_email = filter_var($valor, FILTER_VALIDATE_EMAIL, FILTER_NULL_ON_FAILURE) )
            throw new \Exception(sprintf(ERRO_PADRAO_FORMATO_NAO_CORRESPONDE, __METHOD__), 1500);
        
        return $this->de_email = (string)$valor;
    } // Fim do método _de_email
    
    /**
     * Obter ou editar o valor da propriedade $de_nome
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->de_nome
     * 
     * @return string: valor da propriedade $de_nome
     */
    public function _de_nome($valor=null){
        return is_null($valor) ? (string)$this->de_nome
        : $this->de_nome = (string)$valor;
    } // Fim do método _de_nome
    
    /**
     * Obter ou editar o valor da propriedade $responder_para
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->responder_para
     * 
     * @return string - valor da propriedade $responder_para
     */
    public function _responder_para($valor=null){
        if( is_null($valor) )
            return (string)$this->responder_para;
        
        if( !$this->responder_para = filter_var($valor, FILTER_VALIDATE_EMAIL, FILTER_NULL_ON_FAILURE) )
            throw new \Exception(sprintf(ERRO_PADRAO_FORMATO_NAO_CORRESPONDE, __METHOD__), 1500);
        
        return $this->responder_para = (string)$valor;
    } // Fim do método _responder_para
    
    /**
     * Obter ou editar o valor da propriedade $html
     * @param string $valor - string contendo o valor a ser atribuído à $this->html
     * 
     * @return int: valor da propriedade $html
     */
    public function _html($valor=null){
        if( is_null($valor) )
            return (int)$this->html;
        
        if( (int)$valor < 0 || (int)$valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->html = (int)$valor;
    } // Fim do método _html
    
    /**
     * Obter ou editar o valor da propriedade $principal
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->principal
     * 
     * @return int: valor da propriedade $principal
     */
    public function _principal($valor=null){
        if( is_null($valor) )
            return (int)$this->principal;
        
        if( (int)$valor < 0 || (int)$valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->principal = (int)$valor;
    } // Fim do método _principal
    
    /**
     * Salvar determinado registro
     * 
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){
        # Apenas 1 configuração pode ser definida como principal.
        # Portanto caso a configuração atual esteja sendo configurada
        # como principal, deve-se remover a flag de qualquer outro registro
        if( $this->principal === 1 && $salvar )
            \DL3::$bd_pdo->exec("UPDATE {$this->bd_tabela} SET {$this->bd_prefixo}principal = 0 WHERE {$this->bd_prefixo}principal = 1");
            
        return parent::_salvar($salvar);
    } // Fim do método _salvar
    
    /**
     * Selecionar apenas a configuração principal
     */
    public function _selecionarprincipal(){
        $lis_m = end($this->_listar("{$this->bd_prefixo}principal = 1", null, "{$this->bd_prefixo}id"));
        
        if( $lis_m === false )
            throw new \Exception(ERRO_CONFIGEMAIL_SELECIONARPRINCIPAL, 1404);
        
        $this->_selecionarID($lis_m["{$this->bd_prefixo}id"]);
    } // Fim do método _selecionarprincipal
} // Fim do modelo ConfigModelo
