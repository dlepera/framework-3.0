<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/06/2014 21:14:57
 */

namespace Modelo;

class TipoDadoContato extends Principal{
    # Propriedades do modelo
    protected $id, $descr, $icone, $rede_social = 0, $publicar = 1, $delete = 0;
        
    public function __construct($id=0){
        parent::__construct('dl_site_dados_contato_tipos', 'tipo_dado_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $icone
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->icone
     * 
     * @return string - valor da propriedade $icone
     */
    public function _icone($valor=null){
        return is_null($valor) ? (string)$this->icone
        : $this->icone = (string)$valor;
    } // Fim do método _icone
    
    /**
     * Obter ou editar o valor da propriedade $rede_social
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $this->rede_social
     * 
     * @return int - valor da propriedade $rede_social
     */
    public function _rede_social($valor=null){
        return is_null($valor) ? (int)$this->rede_social
        : $this->rede_social = (int)$valor;
    } // Fim do método _icone
    
    /**
     * Salvar determinado registro
     * 
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){
        # Salvar o arquivo no diretório de uploads do site
        if( file_exists($_FILES['imagem']['tmp_name']) && $salvar ):
            $up = new \Upload('/aplicacao/uploads/contatos/');

            if( $up->_salvar(strtolower(str_replace(' ', '-', \Funcoes::_removeracentuacao($this->descr))), true) )
                $this->icone = $up->arquivos_salvos[0];
            
            # Redimensionar a imagem
            $obj_im = new \Imagem($this->icone);
            $obj_im->_redimensionar(64);
            $obj_im->_salvar($this->icone);
        endif;
        
        return parent::_salvar($salvar);
    } // Fim do método _salvar
    
    /**
     * Remover o registro
     */
    protected function _remover(){
        $rem = parent::_remover();
        
        # Remover o icone desse registro
        if( $rem > 0 ) unlink($this->icone);
        
        return (int)$rem;
    } // Fim do método _remover
} // Fim do modelo TipoDadoContato
