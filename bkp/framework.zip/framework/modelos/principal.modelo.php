<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 20/05/2014 14:54:28
 */

namespace Modelo;

abstract class Principal{
    protected $bd_tabela;
    protected $bd_prefixo;
    protected $bd_select = 'SELECT %s FROM %s WHERE %sdelete = 0';

    # Gravar logs do registro
    private $mod_lr;

    public function __construct($tabela, $prefixo = ''){
        $this->_bd_tabela($tabela);
        $this->_bd_prefixo($prefixo);

        if( get_called_class() !== 'Modelo\LogRegistro' )
            $this->mod_lr = new \Modelo\LogRegistro();
    } // Fim do método mágico de construção

    /**
     * Obter o valor de uma propriedade, utilizando o método
     * de tratamento
     *
     * @param string $nome - nome da propriedade a ser exibida
     *
     * @return mixed - valor da propriedade ou mensagem de erro
     */
    public function __get($nome){
        $metodo = "_{$nome}";

        return method_exists($this, $metodo) ?
            call_user_func_array(array($this, $metodo), array())
        : ERRO_PADRAO_PROPRIEDADE_NAO_EXISTE_OU_NAO_PODE_SER_ACESSADA;
    } // Fim do método mágico __get

    /**
     * Editar o valor de uma propriedade, utilizando o método de
     * tratamento
     *
     * @param string $nome - nome da propriedade a ser alterada
     * @param mixed $valor - valor a ser atribuído a propriedade
     */
    public function __set($nome, $valor){
        $metodo = "_{$nome}";

        return method_exists($this, $metodo) ?
            call_user_func_array(array($this, $metodo), array('valor' => $valor))
        : ERRO_PADRAO_PROPRIEDADE_NAO_EXISTE_OU_NAO_PODE_SER_ALTERADA;
    } // Fim do método mágico __set

    /**
     * Ações padrões a serem executadas quando um determinado método é acionado
     *
     * @param string $nome - Nome do método a ser executado
     * @param array $args - vetor contendo os argumentos a serem passados para o método
     */
    public function __call($nome, $args){
        $mod_registro = 'Modelo\LogRegistro';

        switch($nome):
            # Gravar log de inserção e alteração do registro
            case '_salvar':
                $s = $this->_salvar();

                if( class_exists('Modelo\LogRegistro') && $s > 0 && !is_null($this->id) ):
                    $this->mod_lr->tabela  = $this->bd_tabela;
                    $this->mod_lr->idreg   = $this->id;

                    $this->mod_lr->_salvar();
                endif;

                return $s;

            # Gravar log de remoção
            case '_remover':
                if( ($rem = $this->_remover()) !== false && class_exists($mod_registro) ):
                    $this->mod_lr->tabela  = $this->bd_tabela;
                    $this->mod_lr->idreg   = $this->id;

                    $this->mod_lr->_salvar(true);
                endif;

                return $rem;

            # Selecionar as informações de inclusão e alteração do registro
            case '_selecionarID':
                $this->_selecionarID($args[0], $args[1]);

                if( !is_null($this->id) && get_called_class() != $mod_registro )
                    $this->mod_lr->_selecionarID($this->bd_tabela, $this->id);
                break;
        endswitch;
    } // Fim do método mágico __call

    /**
     * Obter ou editar o valor da propriedade $bd_tabela
     *
     * @param string $valor - string contendo o valor a ser atribuído à $this->bd_tabela
     *
     * @return string - valor da propriedade $bd_tabela
     */
    public function _bd_tabela($valor=null){
        return is_null($valor) ?
            $this->bd_tabela
        : $this->bd_tabela = (string)$valor;
    } // Fim do método _bd_tabela

    /**
     * Obter ou editar o valor da propriedade $bd_prefixo
     *
     * @param string $valor - string contendo o valor a ser atribuído à $this->bd_prefixo
     *
     * @return string - valor da propriedade $bd_prefixo
     */
    public function _bd_prefixo($valor=null){
        return is_null($valor) ?
            (string)$this->bd_prefixo
        : $this->bd_prefixo = (string)$valor;
    } // Fim do método _bd_tabela

    /**
     * Obter ou editar o valor da propriedade $bd_select
     *
     * @param string $valor - string contendo o valor a ser atribuído à $this->bd_select
     *
     * @return string - valor da propriedade $bd_select
     */
    public function _bd_select($valor=null){
        return is_null($valor) ?
            (string)$this->bd_select
        : $this->bd_select = (string)$valor;
    } // Fim do método _bd_tabela

    /**
     * Obter a propriedade $mod_lr
     *
     * @return string - valor da propriedade $bd_prefixo
     */
    public function _mod_lr(){
        return $this->mod_lr;
    } // Fim do método _bd_tabela

    public function _id($v){
        if( !property_exists($this, 'id') )
            return null;

        return is_null($v) ? $this->id
        : $this->id = filter_var($v);
    } // Fim do método _id

    public function _publicar($v){
        if( !property_exists($this, 'publicar') )
            return null;

        if( (int)$v < 0 || (int)$v > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);

        return is_null($v) ? (int)$this->publicar
        : $this->publicar = (int)filter_var($v, FILTER_SANITIZE_NUMBER_INT);
    } // Fim do método _id


    public function _delete(){
        if( !property_exists($this, 'delete') )
            return null;

        return (int)$this->delete;
    } // Fim do método _id

    /**
     * Listar registros desse modelos de acordo com o filtro e ordenação
     *
     * @param string $filtro - parte da string referente à clausula WHERE da consulta SQL
     * @param string $ordem - parte da string referente à clausula ORDER BY da consulta SQL
     * @param string $campos - lista de campos a serem selecionados
     * @param int $pagina - página a ser considerada durante uma paginação de resultados.
     *  Se definida como 0 (zero) a paginação não é realizada
     * @param int $qtde - quantidade de registros a serem exibidos caso a paginação seja
     *  ativada
     *
     * @return array: array associativo contendo o recordset da consulta
     */
    public function _listar($filtro=null, $ordem=null, $campos='*', $pagina=0, $qtde=20){
        $query = substr_count($this->bd_select, '%s') == 2 ?
            sprintf($this->bd_select, $campos, $this->bd_tabela)
        : sprintf($this->bd_select, $campos, $this->bd_tabela, $this->bd_prefixo);

        if( !empty($filtro) )
            $query .= stripos($query, "WHERE") > -1 ? " AND {$filtro}" : " WHERE {$filtro}";

        if( !empty($ordem) )
            $query .= " ORDER BY {$ordem}";
        //echo $query, '<br>--<br>';
        $sql = $pagina > 0 ?
            \DL3::$bd_pdo->_paginacao($query, $pagina, $qtde)
        : \DL3::$bd_pdo->query($query);

        if( !$sql )
            return false;

        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    } // Fim do método _listar

    /**
     * Obter apenas a quantidade de registros
     *
     * @param string $filtro - filtro a ser aplicado na consuta
     */
    public function _qtde_registros($filtro=''){
        $rs = end($this->_listar($filtro, null, 'COUNT(*) AS QTDE'));
        return $rs['QTDE'];
    } // Fim do método _qtde_registros

    /**
     * Selecionar um registro desse modelo pelo ID
     *
     * @param int $id - ID do registro a ser selecionado
     * @param string $alias - alias da tabela principal
     *
     * @return void
     */
    protected function _selecionarID($id, $alias=null){
        if( !method_exists($this, '_listar') )
            throw new \Exception(printf(ERRO_PADRAO_METODO_NAO_EXISTE, '_listar'), 1500);

        # Garantir que o ID seja um número inteiro
        $id     = (int)$id;
        $alias  = is_null($alias) ? '' : (string)"{$alias}.";

        # Armazenar string com campos BIT
        $bit = '';

        if( \DL3::$bd_pdo->getAttribute(\PDO::ATTR_DRIVER_NAME) === 'mysql' ):
            $campos     = \DL3::$bd_pdo->_campos($this->bd_tabela);
            $c_bits     = array_keys(preg_grep('~^bit~', array_column($campos, 'Type')));
            $c_nomes    = array_column($campos, 'Field');

            foreach( $c_bits as $k )
                $bit .= ", {$alias}{$c_nomes[$k]}+0 AS {$c_nomes[$k]}";
        endif;

        $lis_m = end($this->_listar("{$alias}{$this->bd_prefixo}id = {$id}", null, "{$alias}*{$bit}"));

        # Carregar os dados obtidos do banco de dados
        # nas propriedades da classe
        foreach( $lis_m as $c => $m ):
            $p = preg_replace("~^{$this->bd_prefixo}~", '', $c);

            if( property_exists($this, $p) )
               $this->{$p} = $m;
        endforeach;
    } // Fim do método _selecionarID

    /**
     * Salvar determinado registro
     *
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){
        $query = !$this->id ? $this->_criar_insert() : $this->_criar_update();

        if( !$salvar ) return $query;

        if( ($exec = \DL3::$bd_pdo->exec($query)) === false )
            throw new \Exception(
                    sprintf(ERRO_PADRAO_SALVAR_REGISTRO,
                        '<b>'. $this->bd_tabela .':</b><br><br>'. $query .'<br><br>'. \DL3::$bd_pdo->errorInfo()[2]
                    ),
                1500);

        # Se a ação executada foi um insert, carregar o ID gerado
        if( preg_match('~^(INSERT)~', $query) ):
            $this->id = \DL3::$bd_pdo->lastInsertID("{$this->bd_prefixo}id");
            return $this->id;
        else:
            return $exec;
        endif;
    } // Fim do método _salvar

    /**
     * Remover o registro
     */
    protected function _remover(){
        if( $this->delete == 1 ) return 1;

        $rem = \DL3::$bd_pdo->exec("DELETE FROM {$this->bd_tabela} WHERE {$this->bd_prefixo}id = {$this->id}");

        if( $rem === false && property_exists($this, 'delete') )
            $rem = \DL3::$bd_pdo->exec("UPDATE {$this->bd_tabela} SET {$this->bd_prefixo}delete = 1 WHERE {$this->bd_prefixo}id = {$this->id}");

        return (int)$rem;
    } // Fim do método _remover

    /**
     * Criar dinamicamente a consulta INSERT de acordo com os
     * dados do modelo
     *
     * @params bool $inserir_id - Define se a query será montada considerando a inserção
     *  de ID's com IDENTITY ou AUTO_INCREMENT
     *
     * @return string
     */
    public function _criar_insert($inserir_id = false, array $apenas_campos = null, array $excluir_campos = null){
        # Informações dos campos
        array_shift($campos = \DL3::$bd_pdo->_campos($this->bd_tabela));

        $v_campos   = array();
        $v_valores  = array();

        foreach( $campos as $c ):
            # Nome da propriedade
            $p = preg_replace("~^{$this->bd_prefixo}~", '', $c['Field']);

            # Ignorar o campo de marcação da deleção de um registro
            # Ignorar campos que NAO estejam no vetor $apenas_campos, caso o mesmo não seja nulo
            # Ignorar campos que estejam no vetor $excluir_campos, caso o mesmo não seja nulo
            if( $p === 'delete' ||
                    (!is_null($apenas_campos) && !in_array($c['Field'], $apenas_campos)) ||
                    (!is_null($excluir_campos) && in_array($c['Field'], $excluir_campos)) ) continue;

            # Obter as informações do campos
            $pk     = $c['Key'] == 'PRI';
            $obr    = $c['Null'] == 'NO';

            if( is_null($this->{$p}) && $obr && !$pk )
                throw new \Exception(sprintf(ERRO_MODELOPRINCIPAL_CRIARINSERT_CAMPO_OBRIGATORIO_NULO, $c['Field']), 1500);

            if( !is_null($this->{$p}) && (($inserir_id && $pk) || !$pk) ):
                $v_campos[]     = "{$c['Field']}";
                $v_valores[]    = var_export($this->{$p}, true);
            endif;
        endforeach;

        return "INSERT INTO {$this->bd_tabela} (". implode(', ', $v_campos) .") VALUES"
            . " (". implode(', ', $v_valores) .")";
    } // Fim do modelo _criar_insert

    /**
     * Criar dinamicamente a consulta UPDATE de acordo com os
     * dados do modelo
     *
     * @return string
     */
    public function _criar_update(array $apenas_campos = null, array $excluir_campos = null){
        # Informações dos campos
        array_shift($campos = \DL3::$bd_pdo->_campos($this->bd_tabela));

        $v_alterar  = array();
        $v_where    = array();

        foreach( $campos as $c ):
            # Nome da propriedade
            $p = preg_replace("~^{$this->bd_prefixo}~", '', $c['Field']);

            # Ignorar o campo de marcação da deleção de um registro
            # Ignorar campos que NAO estejam no vetor $apenas_campos, caso o mesmo não seja nulo
            # Ignorar campos que estejam no vetor $excluir_campos, caso o mesmo não seja nulo
            if( $p === 'delete' ||
                    (!is_null($apenas_campos) && !in_array($c['Field'], $apenas_campos)) ||
                    (!is_null($excluir_campos) && in_array($c['Field'], $excluir_campos)) ) continue;

            # Obter as informações do campos
            $pk     = $c['Key'] == 'PRI';
            $obr    = $c['Null'] == 'NO';

            if( is_null($this->{$p}) && $obr && !$pk )
                throw new \Exception(sprintf(ERRO_MODELOPRINCIPAL_CRIARUPDATE_CAMPO_OBRIGATORIO_NULO, $c['Field']), 1500);

            if( $pk )
                $v_where[] = "{$c['Field']} = ". var_export($this->{$p}, true);
            else
                $v_alterar[] = "{$c['Field']} = ". var_export($this->{$p}, true);
        endforeach;

        return "UPDATE {$this->bd_tabela} SET ". implode(', ', $v_alterar) ." WHERE ". implode(' AND ', $v_where);
    } // Fim do método _criar_update

    /**
     * Carregar um 'select' com ID e LABEL
     *
     * @param string $filtro - filtro a ser aplicado na query
     * @param boolen $escrever - define se o resultado será escrito no formato json ou retornado
     * @param string $id - nome do campo identificado como 'value' (sem prefixo)
     * @param string $label - nome do campo identificado como 'label' (sem prefixo)
     */
    public function _carregarselect($filtro = null, $escrever = true, $id = 'id', $label = 'descr'){
        $lis = $this->_listar($filtro, "{$this->bd_prefixo}{$label}", "{$this->bd_prefixo}{$id} AS ID, {$this->bd_prefixo}{$label} AS LABEL");

        if( $escrever ) echo json_encode($lis); else return $lis;
    } // Fim _carregarselect
} // Fim do modelo Principal
