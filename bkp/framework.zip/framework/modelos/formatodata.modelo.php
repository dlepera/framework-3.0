<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 13:55:52
 */

namespace Modelo;

class FormatoData extends Principal{
    protected $id, $descr, $completo, $data, $hora, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_painel_formatos_data', 'formato_data_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $completo
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $completo
     * 
     * @return string - valor da propriedade $completo
     */
    public function _completo($valor=null){
        return is_null($valor) ? (string)$this->completo
        : $this->completo = (string)$valor;
    } // Fim do método _completo
    
    /**
     * Obter ou editar o valor da propriedade $data
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->data
     * 
     * @return string - valor da propriedade $data
     */
    public function _data($valor=null){
        return is_null($valor) ? (string)$this->data
        : $this->data = (string)$valor;
    } // Fim do método _data
    
    /**
     * Obter ou editar o valor da propriedade $hora
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->hora
     * 
     * @return string - valor da propriedade $hora
     */
    public function _hora($valor=null){
        return is_null($valor) ? (string)$this->hora
        : $this->hora = (string)$valor;
    } // Fim do método _hora
} // Fim do modelo FormatoData
