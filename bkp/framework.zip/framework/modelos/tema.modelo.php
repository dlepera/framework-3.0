<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 15:39:13
 */

namespace Modelo;

class Tema extends Principal{
    # Propriedades desse modelo
    protected $id, $descr, $diretorio, $padrao = 0, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_painel_temas', 'tema_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $diretorio
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $diretorio
     * 
     * @return string - valor da propriedade $diretorio
     */
    public function _diretorio($valor=null){
        return is_null($valor) ? (string)$this->diretorio
        : $this->diretorio = (string)trim($valor, '/') .'/';
    } // Fim do método _diretorio
    
    /**
     * Obter ou editar o valor da propriedade $padrao
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $padrao
     * 
     * @return int - valor da propriedade $padrao
     */
    public function _padrao($valor=null){
        if( is_null($valor) )
            return (int)$this->padrao;
        
        if( !empty($valor) && ($valor < 0 || $valor > 1) )
            throw new Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->padrao = (int)$valor;
    } // Fim do método _diretorio
        
    /**
     * Salvar determinado registro
     * 
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){
        # Se o tema atual foi definido como padrão, qualquer outro
        # que seja defindo como padrão dever ser removida a flag
        if( $this->padrao == 1 )
            \DL3::$bd_pdo->exec("UPDATE {$this->bd_tabela} SET tema_padrao = 0 WHERE tema_padrao = 1");
        
        return parent::_salvar($salvar);
    } // Fim do método _salvar
} // Fim do modelo Tema
