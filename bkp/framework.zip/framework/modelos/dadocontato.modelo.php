<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/06/2014 21:07:59
 */

namespace Modelo;

class DadoContato extends Principal{
    # Propriedades do modelo
    protected $id, $tipo, $descr, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_site_dados_contato', 'dado_contato_');
        
        # Query de seleção
        $this->bd_select = "SELECT"
            . " %s"
            . " FROM %s AS DC"
            . " INNER JOIN {$this->bd_tabela}_tipos AS TD ON( TD.tipo_dado_id = DC.{$this->bd_prefixo}tipo )"
            . " WHERE DC.%sdelete = 0";
            
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $tipo
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $this->tipo
     * 
     * @return int - valor da propriedade $tipo
     */
    public function _tipo($valor=null){
        return is_null($valor) ? (int)$this->tipo
        : $this->tipo = (int)$valor;
    } // Fim do método _tipo
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ?  (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
} // Fim do método DadoContato
