<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: Jul 24, 2014 4:52:21 PM
 */

namespace Modelo;

class FotoAlbum extends Principal{
    protected $foto_album, $id, $titulo, $descr, $imagem, $capa = 0, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_site_albuns_fotos', 'foto_album_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $foto_album
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $this->foto_album
     * 
     * @return int - valor da propriedade $foto_album
     */
    public function _foto_album($valor=null){
        return is_null($valor) ? (int)$this->foto_album        
        : $this->foto_album = (int)$valor;
    } // Fim do método _foto_album
    
    /**
     * Obter ou editar o valor da propriedade $titulo
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->titulo
     * 
     * @return string - valor da propriedade $titulo
     */
    public function _titulo($valor=null){
        return is_null($valor) ? (string)$this->titulo        
        : $this->titulo = (string)$valor;
    } // Fim do método _titulo
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr        
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $imagem
     * 
     * @param string $valor : string contendo o valor a ser atribuído à $this->imagem
     * 
     * @return string - valor da propriedade $imagem
     */
    public function _imagem($valor=null){
        return is_null($valor) ? (string)$this->imagem        
        : $this->imagem = (string)$valor;
    } // Fim do método _imagem
    
    /**
     * Obter ou editar o valor da propriedade $capa
     * 
     * @param int $valor : string contendo o valor a ser atribuído à $this->capa
     * 
     * @return int: valor da propriedade $capa
     */
    public function _capa($valor=null){
        if( is_null($valor) )
            return (int)$this->capa;
        
        if( !empty($valor) && ($valor < 0 || $valor > 1) )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);

        return $this->capa = (int)$valor;
    } // Fim do método _capa
    
    /**
     * Salvar determinado registro
     * 
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){
        # Caso essa foto esteja sendo definida como capa,
        # remover a flag de qualquer outro registro desse
        # álbum
        if( $this->capa === 1 && $salvar )
            \DL3::$bd_pdo->exec("UPDATE {$this->bd_tabela} SET capa = 0 WHERE foto_album = {$this->foto_album}");
        
        return parent::_salvar($salvar);
    } // Fim do método _salvar
    
    /**
     * Remover o registro
     */
    protected function _remover(){
        $rem = parent::_remover();
        
        # Remover essa foto do drive
        if( $rem ) unlink($this->imagem);
        
        return (int)$rem;
    } // Fim do método _remover
} // Fim do modelo FotoAlbum
