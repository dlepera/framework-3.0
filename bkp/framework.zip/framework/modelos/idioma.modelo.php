<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 16:41:20
 */

namespace Modelo;

class Idioma extends Principal{
    protected $id, $descr, $sigla, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_painel_idiomas', 'idioma_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $sigla
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $sigla
     * 
     * @return string - valor da propriedade $sigla
     */
    public function _sigla($valor=null){
        if( is_null($valor) )
            return $this->sigla;
        
        # Validar o formato da sigla do idioma
        if( !preg_match('~^[a-z]{2}\-[A-Z]{2}~', $valor) )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->sigla = (string)$valor;
    } // Fim do método _descr
} // Fim do modelo Idioma
