<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 15:39:13
 */

namespace Modelo;

class LeituraContato extends Principal{
    # Propriedades desse modelo
    protected $leitura_contato, $id, $usuario, $data, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_site_contatos_leitura', 'leitura_contato_');
        
        $this->bd_select = 'SELECT %s'
                . ' FROM %s AS LC'
                . ' INNER JOIN dl_site_contatos AS CS ON( CS.contato_site_id = LC.leitura_contato )'
                . ' LEFT JOIN dl_painel_usuarios AS U ON( U.usuario_id = LC.leitura_contato_usuario )';
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $leitura_contato
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $leitura_contato
     * 
     * @return int - valor da propriedade $leitura_contato
     */
    public function _leitura_contato($valor=null){
        return is_null($valor) ? (int)$this->leitura_contato
        : $this->leitura_contato = (int)$valor;
    } // Fim do método _leitura_contato
    
    /**
     * Obter ou editar o valor da propriedade $usuario
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $usuario
     * 
     * @return int - valor da propriedade $usuario
     */
    public function _usuario($valor=null){
        return is_null($valor) ? (int)$this->usuario
        : $this->usuario = (int)$valor;
    } // Fim do método _usuario
    
    /**
     * Obter ou editar o valor da propriedade $data
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $data
     * 
     * @return string - valor da propriedade $data
     */
    public function _data($valor=null){
        return is_null($valor) ? (string)\Funcoes::_formatardatahora($this->data, $_SESSION['formato_data_completo'])
        : $this->data = (string)\Funcoes::_formatardatahora($valor, \DL3::$bd_dh_formato_completo);
    } // Fim do método _data
    
    /**
     * Esse modelo deverá possibilitar apenas a inclusão do registro
     */
    protected function _salvar($salvar=true){
        # Verificar se o usuário já leu esse contato
        # anteriormente
        $leu = end($this->_listar("leitura_contato = {$this->leitura_contato} AND leitura_contato_usuario = {$this->usuario}"));
        
        if( $leu ) return true;
        
        $query = $this->_criar_insert();
        
        if( !$salvar ) return $query;
        
        if( ($exec = \DL3::$bd_pdo->exec($query)) === false )
            throw new \Exception(
                    sprintf(ERRO_PADRAO_SALVAR_REGISTRO,
                        '<b>'. $this->bd_tabela .':</b><br><br>'. $query .'<br><br>'. \DL3::$bd_pdo->errorInfo()[2]
                    ),
                1500);
        
        return $this->id = \DL3::$bd_pdo->lastInsertID("{$this->bd_prefixo}id");;
    } // Fim do modelo _salvar
    
    /**
     * Remover a possibilidade de excluir o registro de leitura
     */
    protected function _remover(){
        return false;
    } // Fim do método _remover
} // Fim do modelo LeituraContato
