<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: Jul 24, 2014 4:47:17 PM
 */

namespace Modelo;

class Album extends Principal{
    protected $id, $nome, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_site_albuns', 'album_');
        
        $this->bd_select = "SELECT %s"
            . " FROM %s AS A"
            . " LEFT JOIN dl_site_albuns_fotos AS F ON( F.foto_album = A.{$this->bd_prefixo}id AND F.foto_album_capa = 1 )"
            . " WHERE A.%sdelete = 0";
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $nome
     * 
     * @param string $valor : string contendo o valor a ser atribuído à $this->nome
     * 
     * @return string: valor da propriedade $nome
     */
    public function _nome($valor=null){
        return is_null($valor) ? (string)$this->nome        
        : $this->nome = (string)$valor;
    } // Fim do método _nome
    
    /**
     * Salvar determinado registro
     * 
     * @param boolean $salvar : define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){        
        $s = parent::_salvar($salvar);
        
        # Criar o diretório que receberá as imagens desse álbum
        if( !file_exists($diretorio = "./aplicacao/uploads/albuns/{$this->id}") )
            mkdir($diretorio);
        
        return $s;
    } // Fim do método _salvar
    
    /**
     * Remover o registro
     */
    protected function _remover(){
        # Primeiramente é necessário remover as fotos desse álbum
        $mod_f = new \Modelo\FotoAlbum();
        $lis_f = $mod_f->_listar("foto_album = {$this->id}", null, 'foto_id');
        
        foreach( $lis_f as $f ):
            $mod_f->_selecionarID($f['foto_id']);
            $mod_f->_remover();
        endforeach;
        
        $rem = parent::_remover();
        
        # Por fim, remover o diretório desse álbum
        # PS.: Só funcionará se todas as fotos tiverem sido removidas
        # corretamente
        rmdir("./aplicacao/uploads/albuns/{$this->id}");
        
        return (int)$rem;
    } // Fim do método _remover
} // Fim do modelo Album
