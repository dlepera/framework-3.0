<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 22/05/2014 16:52:19
 */

namespace Modelo;

class LogRegistro extends Principal{
    # Propriedades do modelo
    protected $tabela, $idreg, $data_criacao, $data_alteracao, $data_exclusao, $usuario_criacao, $usuario_alteracao, $usuario_exclusao,
            $ip_criacao, $ip_alteracao, $ip_exclusao;
 
    public function __construct($tabela=null, $idreg=null){
        parent::__construct('dl_painel_registros_logs', 'log_registro_');
        
        # Query de seleção
        $this->bd_select = 'SELECT %s FROM %s';
                
        if( !is_null($tabela) && !is_null($idreg) )
            $this->_selecionarID($tabela, $idreg);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter o valor das propriedades
     * 
     * @param string $nome - nome da propriedade a ser obtida
     */
    public function __get($nome){
        if( property_exists($this, $nome) )          
            return $this->{$nome};
    } // Fim do método mágico __get
    
    /**
     * Obter ou editar o valor da propriedade $tabela
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->tabela
     * 
     * @return string - valor da propriedade $tabela
     */
    public function _tabela($valor=null){
        return is_null($valor) ? (string)$this->tabela
        : $this->tabela = (int)$valor;
    } // Fim do método _tabela
    
    /**
     * Obter ou editar o valor da propriedade $idreg
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->idreg
     * 
     * @return string - valor da propriedade $idreg
     */
    public function _idreg($valor=null){
        return is_null($valor) ? (string)$this->idreg
        : $this->idreg = (int)$valor;
    } // Fim do método _idreg
    
    /**
     * Selecionar um registro desse modelo pelo ID
     * 
     * Obs.: No caso desse modelo a chave é composta: tabela e id do registro
     * 
     * @param string $tabela
     * @param int $idreg - ID do registro a ser selecionado
     * 
     * @return void
     */
    public function _selecionarID($tabela, $idreg){
        if( !method_exists($this, '_listar') )
            throw new \Exception(printf(ERRO_PADRAO_METODO_NAO_EXISTE, '_listar'), 1500);
        
        # Garantir que o ID seja um número inteiro
        # e a tabela uma string
        $idreg  = (int)$idreg;
        $tabela = (string)$tabela;
        
        $lis_m = end($this->_listar("{$this->bd_prefixo}tabela = '{$tabela}' AND {$this->bd_prefixo}idreg = {$idreg}"));
        
        # Carregar os dados obtidos do banco de dados
        # nas propriedades da classe
        foreach( $lis_m as $c => $m ):
            $p = preg_replace("~^{$this->bd_prefixo}~", '', $c);
            
            if( property_exists($this, $p) )
               $this->{$p} = $m;
        endforeach;
    } // Fim do método _selecionarID
    
    /**
     * Salvar determinado registro
     * 
     * @param bool $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    public function _salvar($remover = false, $salvar=true){
        $this->_selecionarID($this->tabela, $this->idreg);
        
        if( is_null($this->data_criacao) || $this->data_criacao == '0000-00-00 00:00:00' ):
            # Complementar informações de inserção
            $this->usuario_criacao     = (int)$_SESSION['usuario_id'];
            $this->data_criacao        = date(\DL3::$bd_dh_formato_completo);
            $this->ip_criacao          = filter_input(INPUT_SERVER, 'REMOTE_ADDR');
            
            $query = "INSERT INTO {$this->bd_tabela} ("
                    . " {$this->bd_prefixo}usuario_criacao, {$this->bd_prefixo}data_criacao, {$this->bd_prefixo}ip_criacao,"
                    . " {$this->bd_prefixo}idreg, {$this->bd_prefixo}tabela) VALUES ("
                    . " {$this->usuario_criacao}, '{$this->data_criacao}', '{$this->ip_criacao}', {$this->idreg}, '{$this->tabela}')";
        else:
            if( !$remover ):
                # Complementar os dados de atualização
                $this->usuario_alteracao   = (int)$_SESSION['usuario_id'];
                $this->data_alteracao      = date(\DL3::$bd_dh_formato_completo);
                $this->ip_alteracao        = filter_input(INPUT_SERVER, 'REMOTE_ADDR');

                $query = "UPDATE {$this->bd_tabela} SET"
                        . " {$this->bd_prefixo}usuario_alteracao = {$this->usuario_alteracao},"
                        . " {$this->bd_prefixo}data_alteracao = '{$this->data_alteracao}',"
                        . " {$this->bd_prefixo}ip_alteracao = '{$this->ip_alteracao}'"
                        . " WHERE {$this->bd_prefixo}idreg = {$this->idreg} AND {$this->bd_prefixo}tabela = '{$this->tabela}'";
            else:
                # Complementar os dados de remoção
                $this->usuario_exclusao    = (int)$_SESSION['usuario_id'];
                $this->data_exclusao       = date(\DL3::$bd_dh_formato_completo);
                $this->ip_exclusao         = filter_input(INPUT_SERVER, 'REMOTE_ADDR');

                $query = "UPDATE {$this->bd_tabela} SET"
                        . " {$this->bd_prefixo}usuario_exclusao = {$this->usuario_exclusao},"
                        . " {$this->bd_prefixo}data_exclusao = '{$this->data_exclusao}',"
                        . " {$this->bd_prefixo}ip_exclusao = '{$this->ip_exclusao}'"
                        . " WHERE {$this->bd_prefixo}idreg = {$this->idreg} AND {$this->bd_prefixo}tabela = '{$this->tabela}'";
            endif;
        endif;
        
        if( !$salvar )
            return $query;
        
        if( ($exec = \DL3::$bd_pdo->exec($query)) === false )
            throw new \Exception(
                sprintf(ERRO_PADRAO_SALVAR_REGISTRO,
                        '<b>'. $this->bd_tabela .':</b><br><br>'. $query .'<br><br>'. \DL3::$bd_pdo->errorInfo()[2]),
                1500);
        
        return $exec;
    } // Fim do método _salvar
} // Fim do modelo LogRegistro
