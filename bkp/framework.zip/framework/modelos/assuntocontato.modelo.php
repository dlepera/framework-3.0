<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 20/05/2014 14:52:19
 */

namespace Modelo;

class AssuntoContato extends Principal{
    # Propriedades do modelo
    protected $id, $descr, $email, $cor = '#000', $publicar = 1, $delete = 0;
 
    public function __construct($id=0){
        parent::__construct('dl_site_assuntos_contato', 'assunto_contato_');
        
        if( !empty($id) )
            $this->_selecionarID ($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr        
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $email
     * 
     * @param string $valor : string contendo o valor a ser atribuído à $this->email
     * 
     * @return string: valor da propriedade $email
     */
    public function _email($valor=null){
        if( is_null($valor) )
            return $this->email;
        
        if( !empty($valor) && !$this->email = filter_var($valor, FILTER_VALIDATE_EMAIL, FILTER_NULL_ON_FAILURE) )
            throw new \Exception(sprintf(ERRO_PADRAO_FORMATO_NAO_CORRESPONDE, __METHOD__), 1500);
        
        return $this->email;
    } // Fim do método _email
    
    /**
     * Obter ou editar o valor da propriedade $cor
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->cor
     * 
     * @return string - valor da propriedade $cor
     */
    public function _cor($valor=null){
        return is_null($valor) ? (string)$this->cor        
        : $this->cor = (string)$valor;
    } // Fim do método _cor
} // Fim do modelo AssuntoContato
