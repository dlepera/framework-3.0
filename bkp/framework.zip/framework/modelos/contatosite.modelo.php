<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 20/05/2014 16:25:07
 */

namespace Modelo;

class ContatoSite extends Principal{
    # Propriedades do modelo
    protected $id, $nome, $email, $telefone, $assunto, $mensagem, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_site_contatos', 'contato_site_');
       
        # Query de seleção
        $this->bd_select = "SELECT"
            . " %s"
            . " FROM %s AS CS"
            . " INNER JOIN dl_site_assuntos_contato AS AC ON( AC.assunto_contato_id = CS.{$this->bd_prefixo}assunto )"
            . " INNER JOIN dl_painel_email_logs AS LE ON( LE.log_email_tabela = '{$this->bd_tabela}' AND LE.log_email_idreg = CS.{$this->bd_prefixo}id )"
            . " INNER JOIN dl_painel_registros_logs AS LR ON( LR.log_registro_tabela = '{$this->bd_tabela}' AND LR.log_registro_idreg = CS.{$this->bd_prefixo}id )"
            . " WHERE CS.%sdelete = 0";
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mégico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $nome
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->nome
     * 
     * @return string - valor da propriedade $nome
     */
    public function _nome($valor=null){
        return is_null($valor) ? (string)$this->nome
        : $this->nome = (string)$valor;
    } // Fim do método _nome
    
    /**
     * Obter ou editar o valor da propriedade $email
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->email
     * 
     * @return string - valor da propriedade $email
     */
    public function _email($valor=null){
        if( is_null($valor) )
            return $this->email;
        
        if( !$this->email = filter_var($valor, FILTER_VALIDATE_EMAIL, FILTER_NULL_ON_FAILURE) )
            throw new \Exception(sprintf(ERRO_PADRAO_FORMATO_NAO_CORRESPONDE, __METHOD__), 1500);
        
        return $this->email;
    } // Fim do método _email
    
    /**
     * Obter ou editar o valor da propriedade $telefone
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->telefone
     * 
     * @return string - valor da propriedade $telefone
     */
    public function _telefone($valor=null){
        return is_null($valor) ?
            (string)$this->telefone
        : $this->telefone = (string)$valor;
    } // Fim do método _telefone
    
    /**
     * Obter ou editar o valor da propriedade $assunto
     * 
     * @param int $valor - ID do assunto a ser vinculado com esse contato
     * 
     * @return int - valor da propriedade $assunto
     */
    public function _assunto($valor=null){
        return is_null($valor) ? (int)$this->assunto
        : $this->assunto = (int)$valor;
    } // Fim do método _assunto
    
    /**
     * Obter ou editar o valor da propriedade $mensagem
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $this->mensagem
     * 
     * @return string - valor da propriedade $mensagem
     */
    public function _mensagem($valor=null){
        return is_null($valor) ?
            (string)$this->mensagem
        : $this->mensagem = (string)$valor;
    } // Fim do método _mensagem
    
    /**
     * Salvar determinado registro
     * 
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     * 
     * Obs.: Esse modelo não tem a opção de alteração dos dados, apenas inserção
     */
    protected function _salvar($salvar=true){        
        $query = $this->_criar_insert();        
        
        if( !$salvar )
            return $query;
        
        if( \DL3::$bd_pdo->exec($query) === false )
             throw new \Exception(sprintf(ERRO_PADRAO_SALVAR_REGISTRO, \DL3::$bd_pdo->errorInfo()[2]), 1500);
        
        return $this->id = \DL3::$bd_pdo->lastInsertID("{$this->bd_prefixo}id");
    } // Fim do método _salvar
    
    /**
     * Relatório de contatos recebidos
     * ---------------------------------
     * Gerar um relatório simples para mostrar quantos contatos foram recebidos
     * para cada assunto
     * 
     * @return string [HTML] tabela demosntrando o resultado do relatório
     */
    public function _rel_contar_por_assuntos(){
        $num = $this->_qtde_registros();
        
        $lis = $this->_listar(
            '1=1 GROUP BY assunto_contato_id', 'assunto_contato_descr',
            "COUNT({$this->bd_prefixo}id) AS QTDE, assunto_contato_descr, assunto_contato_cor"
        );
        
        $tabela = '<table class="conteudo"><tbody>';
        
        foreach($lis as $d):
            $p100 = round(($d['QTDE']*100)/$num);
        
            $tabela .= "<tr style='color: {$d['assunto_contato_cor']}'>"
                . "<td>{$d['assunto_contato_descr']}</td>"
                . "<td>{$d['QTDE']} ({$p100}%)</td>"
                . '</tr>';
        endforeach;
        
        $tabela .= '</tbody><tfoot>'
                . '<tr style="color: #000">'
                . '<td>'. TXT_LABEL_TOTAL .'</td>'
                . "<td>{$num} (100%)</td>"
                . '</tr></tfoot></table>';
        
        return $tabela;
    } // Fim do método _rel_contar_por_assuntos
    
    public function _registrar_leitura(){
        $mod_lc = new \Modelo\LeituraContato();
        $mod_lc->leitura_contato    = $this->id;
        $mod_lc->usuario            = $_SESSION['usuario_id'];
        $mod_lc->data               = date(\Dl::$bd_dh_formato_completo);
        $mod_lc->_salvar();
    } // Fim do método _registrar_leitura
    
    public function _listar_leitura(){
        $mod_lc = new \Modelo\LeituraContato();
        
        $lis = $mod_lc->_listar("leitura_contato = {$this->id}", 'leitura_contato_data DESC', 'usuario_info_nome, leitura_contato_data');
        
        $html = '<p>';
        
        foreach( $lis as $d ):
            $html .= sprintf(MSG_LIDO_POR, $d['usuario_info_nome'], \Funcoes::_formatardatahora($d['leitura_contato_data'], $_SESSION['formato_data_completo'])) .'<br/>';
        endforeach;
        
        $html .= '</p>';
        
        return $html;
    } // Fim do método _listar_leitura
} // Fim do Modelo ContatoSite
