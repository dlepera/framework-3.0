<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 30/05/2014 21:40:50
 */

namespace Modelo;

class PermissoesUsuario extends Principal{
    # Propriedades desse modelo
    protected $usuario, $modulo, $ver = 0, $inserir = 0, $editar = 0, $remover = 0, $total = 0;
    
    public function __construct($u = null, $m = null){
        parent::__construct('dl_painel_usuarios_permissoes', 'permissao_');
       
        # Query de seleção
        $this->bd_select = 'SELECT %s FROM %s';
        
        if( !empty($u) && !empty($m) )
            $this->_selecionarID($u, $m);
    } // Fim do método mágico de construção da classe
        
    /**
     * Selecionar um registro desse modelo pelo ID
     * 
     * @param int $usuario - ID do usuário
     * @param int $modulo - ID do módulo
     * 
     * @return void
     */
    public function _selecionarID($usuario, $modulo){
        if( !method_exists($this, '_listar') )
            throw new \Exception(printf(ERRO_PADRAO_METODO_NAO_EXISTE, '_listar'), 1500);
        
        # Garantir que os IDs sejam números inteiros
        $usuario = (int)$usuario;
        $modulo  = (int)$modulo;
        
        $lis_m = end($this->_listar("{$this->bd_prefixo}usuario = {$usuario} AND {$this->bd_prefixo}modulo = {$modulo}"));
        
        # Carregar os dados obtidos do banco de dados
        # nas propriedades da classe
        foreach( $lis_m as $c => $m ):
            if( property_exists($this, $c) )
               $this->{$c} = $m;
        endforeach;
    } // Fim do método _selecionarID
    
    /**
     * Obter ou editar o valor da propriedade $usuario
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $usuario
     * 
     * @return int - valor da propriedade $usuario
     */
    public function _usuario($valor=null){
        return is_null($valor) ? (int)$this->usuario
        : $this->usuario = (int)$valor;
    } // Fim do método _usuario
    
    /**
     * Obter ou editar o valor da propriedade $modulo
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $modulo
     * 
     * @return int: valor da propriedade $modulo
     */
    public function _modulo($valor=null){
        return is_null($valor) ? (int)$this->modulo
        : $this->modulo = (int)$valor;
    } // Fim do método _modulo
    
    /**
     * Obter ou editar o valor da propriedade $ver
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $ver
     * 
     * @return int - valor da propriedade $ver
     */
    public function _ver($valor=null){
        if( is_null($valor) )
            return (int)$this->ver;
        
        if( $valor < 0 || $valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->ver = (int)$valor;
    } // Fim do método _ver
    
    /**
     * Obter ou editar o valor da propriedade $inserir
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $inserir
     * 
     * @return int - valor da propriedade $inserir
     */
    public function _inserir($valor=null){
        if( is_null($valor) )
            return (int)$this->inserir;
        
        if( $valor < 0 || $valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->inserir = (int)$valor;
    } // Fim do método _inserir
    
    /**
     * Obter ou editar o valor da propriedade $editar
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $editar
     * 
     * @return int - valor da propriedade $editar
     */
    public function _editar($valor=null){
        if( is_null($valor) )
            return (int)$this->editar;
        
        if( $valor < 0 || $valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->editar = (int)$valor;
    } // Fim do método _editar
    
    /**
     * Obter ou editar o valor da propriedade $remover
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $remover
     * 
     * @return int - valor da propriedade $remover
     */
    public function _remover($valor=null){
        if( is_null($valor) )
            return (int)$this->remover;
        
        if( $valor < 0 || $valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->remover = (int)$valor;
    } // Fim do método _remover
    
    /**
     * Obter ou editar o valor da propriedade $total
     * 
     * @param int $valor - string contendo o valor a ser atribuído à $total
     * 
     * @return int - valor da propriedade $total
     */
    public function _total($valor=null){
        if( is_null($valor) )
            return (int)$this->total;
        
        if( $valor < 0 || $valor > 1 )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->total = (int)$valor;
    } // Fim do método _total
    
    /**
     * Salvar determinado registro
     * 
     * Obs.: Esse modelo não terá a opção de editar
     * 
     * @param boolean $salvar - define se o registro será salvo ou apenas
     * será gerada a query de insert/update
     */
    protected function _salvar($salvar=true){
        $query = !$this->_qtde_registros("permissao_usuario = {$this->usuario} AND permissao_modulo = {$this->modulo}") ?
            $this->_criar_insert(true)
        : $this->_criar_update();
                
        if( !$salvar )
            return $query;
        
        if( ($exec = \DL3::$bd_pdo->exec($query)) === false )
            throw new \Exception(sprintf(ERRO_PADRAO_SALVAR_REGISTRO, \DL3::$bd_pdo->errorInfo()[2]), 1500);
        
        return $exec;
    } // Fim do método _salvar
} // Fim do modelo PermissoesUsuario
