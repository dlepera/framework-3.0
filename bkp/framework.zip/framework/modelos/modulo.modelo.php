<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 16:55:06
 */

namespace Modelo;

class Modulo extends Principal{
    protected $id, $pai = null, $nome, $descr, $link, $publicar = 1, $ordem = 0, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_painel_modulos', 'modulo_');
        
        # Query de seleção
        $this->bd_select = "SELECT"
            . " %s"
            . " FROM %s AS M"
            . " LEFT JOIN {$this->bd_tabela} AS P ON( P.{$this->bd_prefixo}id = M.{$this->bd_prefixo}pai )"
            . " WHERE M.%sdelete = 0";
            
        if( !empty($id) )
            $this->_selecionarID($id, 'M');
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $pai
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $pai
     * 
     * @return string - valor da propriedade $pai
     */
    public function _pai($valor=null){
        return is_null($valor) ?(int)$this->pai
        : $this->pai = $valor > 0 ? (int)$valor : NULL;
    } // Fim do método _pai
    
    /**
     * Obter ou editar o valor da propriedade $nome
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $nome
     * 
     * @return string - valor da propriedade $nome
     */
    public function _nome($valor=null){
        return is_null($valor) ? (string)$this->nome
        : $this->nome = (string)$valor;
    } // Fim do método _nome
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
    
    /**
     * Obter ou editar o valor da propriedade $link
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $descr
     * 
     * @return string - valor da propriedade $link
     */
    public function _link($valor=null){
        return is_null($valor) ? (string)$this->link
        : $this->link = (string)trim($valor, '/');
    } // Fim do método _link
    
    /**
     * Obter ou editar o valor da propriedade $ordem
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $ordem
     * 
     * @return string - valor da propriedade $ordem
     */
    public function _ordem($valor=null){
        return is_null($valor) ? (int)$this->ordem
        : $this->ordem = (int)$valor;
    } // Fim do método _descr
} // Fim do modelo Modulo
