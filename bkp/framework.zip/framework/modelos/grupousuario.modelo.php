<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 16:07:59
 */

namespace Modelo;

class GrupoUsuario extends Principal{
    protected $id, $descr, $publicar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_painel_grupos_usuarios', 'grupo_usuario_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $descr
     * 
     * @param string $valor - string contendo o valor a ser atribuído à $descr
     * 
     * @return string - valor da propriedade $descr
     */
    public function _descr($valor=null){
        return is_null($valor) ? (string)$this->descr
        : $this->descr = (string)$valor;
    } // Fim do método _descr
} // Fim do modelo GrupoUsuario
