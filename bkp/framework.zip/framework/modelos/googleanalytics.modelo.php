<?php

/**
 * @Autor	: Diego Lepera
 * @E-mail	: d_lepera@hotmail.com
 * @Projeto	: FrameworkDL
 * @Data	: 26/05/2014 15:39:13
 */

namespace Modelo;

class GoogleAnalytics extends Principal{
    # Propriedades desse modelo
    protected $id, $usuario, $senha, $perfil_id, $ativar = 1, $delete = 0;
    
    public function __construct($id=0){
        parent::__construct('dl_site_google_analytics', 'ga_');
        
        if( !empty($id) )
            $this->_selecionarID($id);
    } // Fim do método mágico de construção da classe
    
    /**
     * Obter ou editar o valor da propriedade $usuario
     * 
     * @param string $v - string contendo o valor a ser atribuído à $usuario
     * 
     * @return string - valor da propriedade $usuario
     */
    public function _usuario($v=null){
        return is_null($v) ? (string)$this->usuario
        : $this->usuario = (string)$v;
    } // Fim do método _usuario
    
    /**
     * Obter ou editar o valor da propriedade $senha
     * 
     * @param string $v - string contendo o valor a ser atribuído à $senha
     * 
     * @return string - valor da propriedade $senha
     */
    public function _senha($v=null){
        return is_null($v) ? (string)$this->senha
        : $this->senha = (string)$v;
    } // Fim do método _senha
    
    /**
     * Obter ou editar o valor da propriedade $perfil_id
     * 
     * @param int $v - string contendo o valor a ser atribuído à $perfil_id
     * 
     * @return int - valor da propriedade $perfil_id
     */
    public function _perfil_id($v=null){
        return is_null($v) ? (int)$this->perfil_id
        : $this->perfil_id = (int)$v;
    } // Fim do método _perfil_id
    
    /**
     * Obter ou editar o valor da propriedade $ativar
     * 
     * @param int $v - string contendo o valor a ser atribuído à $ativar
     * 
     * @return int - valor da propriedade $ativar
     */
    public function _ativar($v=null){
        if( is_null($v) ) return (int)$this->ativar;
        
        if( !empty($v) && ( $v < 0 || $v > 1 ) )
            throw new \Exception(sprintf(ERRO_PADRAO_VALOR_INVALIDO, __METHOD__), 1500);
        
        return $this->ativar = (int)$v;
    } // Fim do método _ativar
    
    /**
     * Esse modelo deverá possibilitar apenas a inclusão do registro
     */
    protected function _salvar($salvar=true){
        if( $this->ativar == 1 )
            \DL3::$bd_pdo->exec("UPDATE {$this->bd_tabela} SET {$this->bd_prefixo}ativar = 0");
            
        return $this->_salvar($salvar);
    } // Fim do modelo _salvar
} // Fim do modelo GoogleAnalytics
